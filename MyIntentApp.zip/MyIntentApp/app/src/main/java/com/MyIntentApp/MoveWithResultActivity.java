package com.MyIntentApp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MoveWithResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move_with_result);
    }
}